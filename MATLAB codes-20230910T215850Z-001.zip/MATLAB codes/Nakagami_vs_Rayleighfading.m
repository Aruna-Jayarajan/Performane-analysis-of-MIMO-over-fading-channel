m = 1.5; % Nakagami-m parameter
EbN0dB = 0:2:20; % Range of Eb/N0 values in dB
nbits = 1e6; % Number of bits to transmit
M = 4; % Modulation order (4 for QPSK)

% Generate random bits
txBits = randi([0 1], [nbits 1]);

% Modulate bits using QPSK modulation
txSym = qammod(txBits, M);

% Compute symbol energy
Es = mean(abs(txSym).^2);

% Loop over range of Eb/N0 values
for i = 1:length(EbN0dB)
    
    % Compute noise power spectral density
    EbN0 = 10^(EbN0dB(i)/10);
    N0 = Es/(2*EbN0);
    
    % Generate Nakagami-m or Rayleigh fading gain
    if m > 0
        h = sqrt(random('gam', m, 1, [nbits 1])/m); % Nakagami-m fading
    else
        h = sqrt(0.5)*(randn([nbits 1]) + 1j*randn([nbits 1])); % Rayleigh fading
    end
    
    % Apply fading gain to signal
    rxSig = h.*txSym;
    
    % Add AWGN to signal
    noise = sqrt(N0/2)*(randn(size(rxSig)) + 1j*randn(size(rxSig)));
    rxSig = rxSig + noise;
    
    % Demodulate received signal using QPSK demodulation
    rxBits = qamdemod(rxSig, M);
    
    % Compute BER
    ber(i, 1) = sum(txBits ~= rxBits)/nbits;
end

% Compute theoretical BER for Nakagami-m fading
if m > 0
    SNR = 10.^(EbN0dB/10);
    ber_theory = 0.5.*(1 - sqrt((m./(m+SNR))));
end

% Compute theoretical BER for Rayleigh fading
SNR = 10.^(EbN0dB/10);
ber_theory_rayleigh = 0.5.*(1 - sqrt(1./(1+SNR)));

% Plot BER vs Eb/N0
%semilogy(EbN0dB, ber(:,1), 'o-', 'DisplayName', 'Nakagami-m');
hold on;
semilogy(EbN0dB, ber_theory, 'r--', 'DisplayName', 'Nakagami-m (Theory)');
semilogy(EbN0dB, ber_theory_rayleigh, 'g-.', 'DisplayName', 'Rayleigh (Theory)');
xlabel('Eb/N0 (dB)');
ylabel('BER');
title(sprintf('BER comparison between Nakagami-m and Rayleigh channels (m=%.1f)', m));
grid on;
legend;
saveas(gcf,'Nakagami_Rayleigh.png')