 if true
%Ergodic_Capacity: MATLAB code - Slight modi¯cation for outage code
% mT, Number of transmitting antennas
% mR, Number of transmitting antennas
% ITER, number of trials
% SNRdB, Range of SNR in dB
% C SISO, variable for capacity of a SISO system
% C SIMO, variable for capacity of a SIMO system
% C MISO, variable for capacity of a MISO system
% C MIMO, variable for capacity of a MIMO system
% h SISO, random channel for SISO (with zero mean unit variance)
% h SIMO, random channel for SIMO
% h MISO, random channel for MISO
% h MIMO, random channel for MIMO
clc;
close all;
clear all;
%set the number of transmitter and reciever atenna to be 2
mT = 2;
mR = 2;
ITER = 1000;
bandwidth = 1e6; % Bandwidth in Hz (e.g., 1 MHz)

%SNR range from 0 to 30 dB
SNRdB = [0:30];
SNR = 10.^(SNRdB/10); % convert SNR to linear scale 
% create a zero matrix for all 
% Generate complex channel coefficient
C_SISO = zeros(1,length(SNR));
C_SIMO = zeros(1,length(SNR));
C_MISO = zeros(1,length(SNR));
C_MIMO = zeros(1,length(SNR));
for ite = 1:ITER
 % complex number by adding a random number
 % drawn from a standard normal distribution
 % to the real part, and a random number drawn from a 
 % standard normal distribution multiplied by the imaginary
 % unit i to the imaginary part. The division by sqrt(2) 
 % scales the resulting complex number to have unit variance.
h_SISO = (randn +1i*randn)/sqrt(2); 
%h_SISO will hold a complex number generated from a standard complex 
% normal distribution, with zero mean and unit variance.

h_SIMO = (randn(mR,1)+1i*randn(mR,1))/sqrt(2); 
h_MISO = (randn(1,mT)+1i*randn(1,mT))/sqrt(2); 
h_MIMO = (randn(mR,mT)+1i*randn(mR,mT))/sqrt(2); 

for K = 1:length(SNR)
C_SISO(K) = C_SISO(K) + bandwidth* log2(1+ SNR(K)*norm(h_SISO)^2); % 𝐶=𝐵log2(1+𝑆𝑁) 
C_SIMO(K) = C_SIMO(K) + bandwidth* log2(1+ SNR(K)*norm(h_SIMO)^2/mR);%𝐶=𝐵log2(1+𝑀𝑅𝑆𝑁)
C_MISO(K) = C_MISO(K) + bandwidth* log2(1+ SNR(K)*norm(h_MISO)^2/mT);%𝐶=𝐵log2(1+𝑀𝑇𝑆𝑁)
C_MIMO(K) = C_MIMO(K) + bandwidth* log2(abs(det(eye(mR)+SNR(K)*h_MIMO*h_MIMO'/mT))); %𝐶=𝐵log2(1+𝑀𝑅.𝑀𝑇𝑆𝑁)
end
end
C_SISO = C_SISO/ITER; 
C_SIMO = C_SIMO/ITER;
C_MISO = C_MISO/ITER;
C_MIMO = C_MIMO/ITER;
plot( SNRdB,C_SISO,'r',SNRdB,C_SIMO,'b',SNRdB, C_MISO,'m',SNRdB,C_MIMO,'k',LineWidth=1)
% SNRdB,C_MIMO,'r-*'
legend('SISO','SIMO','MISO','MIMO')

title('Capacity Vs. SNR')
set(gca,'XTick',0:5:30); %re-name axis accordingly
xlabel('SNR in dB')
ylabel('Capacity (b/s/Hz)')
grid on;
%saveas(gcf,'sisomimosnr.png')
saveas(gcf,'mimo_all.png')
  end
