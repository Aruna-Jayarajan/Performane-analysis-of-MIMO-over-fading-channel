function ls = LS_siso() 
clear all 
%%%%%%%%%% System Parameters %%%%%%%%%%%%%%%%%%%%%%%%%%% 
T=1; 
R=1; 
%LS SISO 
mod_scheme = input('Set Modulation Scheme 2(BPSK) 4(QAM) 8(8QAM) = '); 
%%%%% OFDM Parameters %%%%%%%%%%%%% 
zero_pad =0; 
block_size = 64; 
data_size = block_size -zero_pad ;
prefix_size = 0 ; 
total_block_size = block_size + prefix_size ;
E_db =0: 5 :30; 
err_rate_Eb_LS = [ ones(1,length(E_db) ) ] ; 
%tic 
it =7;

ber = []; 
for l =1:length(E_db) 
    for k=1:it 
        for h=1:T 
            x(h,:) = randi(1,block_size,mod_scheme);
        end 
        switch mod_scheme 
            case 2 
                X = 2*x-1; 
            case 4 
                X = qammod(x,4); 
            case 8 
                X = qammod(x,8); 
        end 
        X_ofdm = fft(X,64); 
        h = randn (R,T) + j*randn (R,T);
        H = fft(h,64); 
        Y = X_ofdm.*H;
        Y=awgn(Y,E_db(l));
        hls_est = Y./X_ofdm;
        ms_error=(((abs(hls_est-H))/abs(H)).^2);
        ls_mse(it ,l) = ms_error;
        rec_x_ofdm = Y./hls_est; 
        rec_x_mod = ifft(rec_x_ofdm,64); 
        rec_x = qamdemod(rec_x_mod,mod_scheme); 
    end 
    [num_bit_LS , ratio_bit_LS] = biterr(x,rec_x); 
    ber = [ ber ratio_bit_LS]; 
end
%ber 
ms_avg = mean(ls_mse); 
freqz(x)
hold on 
title('Frequency Response for Input and Output'); 
pause 
freqz(rec_x) 
scatterplot(hls_est)
title('Estimated Channel'); 
scatterplot(H) 
title('Actual Channel'); 
figure semilogy(E_db,ms_avg,'b-'); 
xlabel('SNR in DB');
ylabel('mean squared error'); 
title('SNR V/S MSE FOR AN OFDM SYSTEM WITH LS ESTIMATOR BASED RECEIVERS');
figure plot(E_db,ber,'b'); xlabel('SNR in DB'); ylabel('Bit Error Rate'); title('Bit error Rate Plot At different values of SNR');