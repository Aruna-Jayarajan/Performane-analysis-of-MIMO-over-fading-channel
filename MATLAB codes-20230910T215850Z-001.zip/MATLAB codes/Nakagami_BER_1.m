% Nakagami-m Fading Channel Simulation

% Set simulation parameters
m = 0.5; % shape parameter
Es = 1; % symbol energy
No = 1; % noise power spectral density
omega = 1; % RMS channel gain
snr_dB = 0:2:20; % SNR range in dB

% Convert SNR from dB to linear scale
snr = 10.^(snr_dB./10);

% Calculate gamma
gamma = (m*Es)./(2*No*omega.^2*snr);

% Calculate BER using the Nakagami-m BER formula
ber = 0.5*erfc(sqrt(gamma));

% Plot BER vs SNR
semilogy(snr_dB,ber,'bo-');
xlabel('SNR (dB)');
ylabel('BER');
title(['Nakagami-m Fading, m = ' num2str(m)]);
grid on;