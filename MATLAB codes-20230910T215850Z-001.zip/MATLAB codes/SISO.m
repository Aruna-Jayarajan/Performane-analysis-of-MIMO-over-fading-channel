clc;
clear all;
close all;

c= 3e8;
fc = 20e9;
lambda = c/fc;

%Transmitter and Reciver position
txcenter = [0;0;0];
rxcenter = [1600;900;0]; %2.5km

%Tx and Rx angles 
[~,txang] = rangeangle(rxcenter,txcenter);
[~,rxang] = rangeangle(txcenter,rxcenter);

%tx rx input  and output
txipos =[0;0;0];
rxopos =[0;0;0];

%phased unifrom linear array
%rxarray = phased.ULA('NumElements',4,'ElementSpacing',lambda/2);
%rxmopos = getElementPosition(rxarray)/lambda;

%gain
g=1;

%SISO scattering matrix
sisochan = scatteringchanmtx(txipos,rxopos,txang,rxang,g);

%BPSK modulation BER
Nsamp = 1e6; % 10 lakh samples
x = randi([0 1],Nsamp,1) %uniformly distributed pseudorandom integer

ebn0_param = -10:2:10;
Nsnr = numel(ebn0_param);

%BER
ber_siso = BER

