n = 3; % Shape parameter
omega = 1; % Scale parameter
x = linspace(0, 5, 1000); % Input values
y = nakagami(n, omega, x); % Output values
plot(x, y); % Plot the Nakagami distribution