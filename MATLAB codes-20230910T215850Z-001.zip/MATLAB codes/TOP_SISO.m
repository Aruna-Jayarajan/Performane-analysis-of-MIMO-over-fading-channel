clc;
close all;
clear all;
len = 100000;
snr_lmt = 0:1:20; %snr range
modulation_ind = 2;
data = randsrc(1, len, 0:1);
data_mod = modulate_process(data,modulation_ind);
snr_range=snr_lmt;
index =1;
for k1=1:length(snr_range)
    %noise channel
    noise=1/sqrt(2)*(randn(1,len)+ j*randn(1,len));
    channel_mat= uncorr_rayleigh_channel(len);
    rx_data = channel_mat.*dat_mod + 10^(-snr_range(k1)/20)*noise;
    rx_data2 = rx_data./channel_mat;
    data_out= demodulate_process(rx_data2);
    [erramt errrate] = biterr(data,data_out) %find bit error rate
    final_err1(index) = errrate;
    final_snr1(index) = snr_range(k1);

    index=index+1;
end
final_err1 = sort(final_err1,'descend');
pause(2);

%% QPSK
disp(" QPSK SISO");
modulation_ind = 3;
data = randsrc(1,len,0:modulation_ind -1); %message
data_mod = modulate_process

