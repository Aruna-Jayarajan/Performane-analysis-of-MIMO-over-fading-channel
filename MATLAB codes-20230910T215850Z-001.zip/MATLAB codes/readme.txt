Convert Image To And From Graph Cooridinates
--------------------------------------------
main executing reference usage: usage_ImageToAndFromGraphCooridinates.m

The objective is to illustrate how to map a 2-level image, ie. black-and-white image, to graph cooridinates and vice-versa.

* Caveat: For demo reference only.
- Certain conditions are also to be noted, please refer to notes at the demo codes.

If the demo has a more elegant presentation, please do not hesitate to suggest and send feedback to author.
Email: promethevx@yahoo.com.

Thank you.

Regards,
Michael Chan JT

-------------------------------------- EOF --------------------------------------