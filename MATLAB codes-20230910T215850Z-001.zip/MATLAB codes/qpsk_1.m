clear all;close all;clc
M=16; % Modulation Order
tx = 1;
rx=5; % No. of receive antennas
snr=0:50; % signal to noise ratio
bit_errors = zeros(length(snr), 1); % Configure average BER vector
loop=10000;
for ii=1:length(snr)
cur_bit_errors = zeros(1, loop); % Configure calculated BER vector
for l=1:loop
data=randi([0 M-1], 1, 1); % Input Signal
u=qammod(data, M, 'Gray'); % Modulate
h = (randn(rx, 1) + 1i*randn(rx, 1)) / sqrt(2); % SIMO Freq.flat rayleigh fading channel
y1=h.*u; % Multiply
y2=awgn(y1, snr(ii)); % AWGN
y3=(h'*y2)/norm(h)^2; % Maximum Receiver Ratio Combining
y4=qamdemod(y3, M, 'Gray'); % Demodulate
cur_bit_errors(l)=biterr(data, y4); % Bit Error calculation
end
bit_errors(ii) = mean(cur_bit_errors); % Average BER
end
semilogy(snr , bit_errors); % plot with logarithmic y-axis
grid on; % show a grid
xlabel('SNR [dB]'); ylabel('BER'); % label x- and y-axis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%