 if true
%Ergodic_Capacity: MATLAB code - Slight modi¯cation for outage code
% mT, Number of transmitting antennas
% mR, Number of transmitting antennas
% ITER, number of trials
% SNRdB, Range of SNR in dB
% C SISO, variable for capacity of a SISO system
% C SIMO, variable for capacity of a SIMO system
% C MISO, variable for capacity of a MISO system
% C MIMO, variable for capacity of a MIMO system
% h SISO, random channel for SISO (with zero mean unit variance)
% h SIMO, random channel for SIMO
% h MISO, random channel for MISO
% h MIMO, random channel for MIMO
clc;
close all;
clear all;
mT = 4;
mR = 4;
ITER = 1000;

SNRdB = [0:30];
SNR = 10.^(SNRdB/10);
C_SISO = zeros(1,length(SNR));
C_SIMO = zeros(1,length(SNR));
C_MISO = zeros(1,length(SNR));
C_MIMO = zeros(1,length(SNR));
for ite = 1:ITER
h_SISO = (randn +1i*randn)/sqrt(2);
h_SIMO = (randn(mR,1)+1i*randn(mR,1))/sqrt(2);
h_MISO = (randn(1,mT)+1i*randn(1,mT))/sqrt(2);
h_MIMO = (randn(mR,mT)+1i*randn(mR,mT))/sqrt(2);
for K = 1:length(SNR)
C_SISO(K) = C_SISO(K) + log2(1+ SNR(K)*norm(h_SISO)^2);
C_SIMO(K) = C_SIMO(K) + log2(1+ SNR(K)*norm(h_SIMO)^2);
C_MISO(K) = C_MISO(K) + log2(1+ SNR(K)*norm(h_MISO)^2/mT);
C_MIMO(K) = C_MIMO(K) + log2(abs(det(eye(mR)+SNR(K)*h_MIMO*h_MIMO'/mT)));
end
end
C_SISO = C_SISO/ITER; 
C_SIMO = C_SIMO/ITER;
C_MISO = C_MISO/ITER;
C_MIMO = C_MIMO/ITER;
plot(SNRdB,C_MIMO,'r-*' );
    %,SNRdB,C_SIMO,'b',SNRdB, C_MISO,'m',SNRdB,C_MIMO,'k',Marker='x',LineWidth=1.5)
% 
legend('MIMO')
%,'SIMO','MISO','MIMO')

title('Capacity Vs. SNR')
set(gca,'XTick',0:5:30); %re-name axis accordingly
xlabel('SNR in dB')
ylabel('Capacity (b/s/Hz)')
grid on;
%saveas(gcf,'sisomimosnr.png')
saveas(gcf,'mimo_all.png')
  end
