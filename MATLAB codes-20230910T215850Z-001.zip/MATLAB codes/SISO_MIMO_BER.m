%% Improve SNR and Capacity of Wireless Communication Using Antenna Arrays

%% Introduction

% For this example, assume the system is deployed at 60 GHz, which is a frequency being considered for the 5G system.

c = 3e8;        % propagation speed
fc = 6e9;      % carrier frequency
lambda = c/fc;  % wavelength

rng(6466);

%%
% With no loss in generality, place the transmitter at the origin and place the receiver approximately 2.5 km away.

txcenter = [0;0;0];
rxcenter = [900;1600;0];


%% Improve SNR by Array Gain for Line of Sight Propagation

% error rate (BER).
%
% *SISO LOS Channel*
% 
% A SISO LOS channel has a direct path from the transmitter to the
% receiver. Such a channel can be modeled as a special case of the
% multipath channel.

[~,txang] = rangeangle(rxcenter,txcenter);
[~,rxang] = rangeangle(txcenter,rxcenter);

txsipos = [0;0;0];
rxsopos = [0;0;0];

g = 1;  % gain for the path
sisochan = scatteringchanmtx(txsipos,rxsopos,txang,rxang,g);

%%
% Using BPSK modulation, the bit error rate (BER) for such a SISO channel
% can be plotted as

Nsamp = 1e6;
x = randi([0 1],Nsamp,1);

ebn0_param = -10:2:10;
Nsnr = numel(ebn0_param);

ber_siso = helperMIMOBER(sisochan,x,ebn0_param)/Nsamp;
%helperBERPlot(ebn0_param,ber_siso);
legend('SISO')

%% 
% *SIMO LOS Channel*
%
% With the baseline established for a SISO system, this section focuses on
% the single input multiple output (SIMO) system. In such a system, there is
% one transmit antenna but multiple receive antennas. Again, it is assumed
% that there is a direct path between the transmitter and the receiver.
%
% Assume the receive array is a 4-element ULA with half-wavelength spacing,
% then the SIMO channel can be modeled as

rxarray = phased.ULA('NumElements',4,'ElementSpacing',lambda/2);
rxmopos = getElementPosition(rxarray)/lambda;

simochan = scatteringchanmtx(txsipos,rxmopos,txang,rxang,g);

%%
% In the SIMO system, because the received signals across receive array
% elements are coherent, it is possible to steer the receive array toward
% the transmitter to improve the SNR. Note that this assumes that the
% signal incoming direction is known to the receiver. In reality, the angle
% is often obtained using direction of arrival estimation algorithms.

rxarraystv = phased.SteeringVector('SensorArray',rxarray,...
    'PropagationSpeed',c);
wr = conj(rxarraystv(fc,rxang));
ber_simo = helperMIMOBER(simochan,x,ebn0_param,1,wr)/Nsamp;
%helperBERPlot(ebn0_param,[ber_siso(:) ber_simo(:)]); 
legend('SISO','SIMO')


%% 
% *MISO LOS Channel*
%
% With the baseline established for a SISO system, this section focuses on
% the single input multiple output (MISO) system. In such a system, there is
% Multiple transmit antenna but one receive antennas. Again, it is assumed
% that there is a direct path between the transmitter and the receiver.
%
% Assume the transmit array is a 4-element ULA with half-wavelength spacing,
% then the MISO channel can be modeled as

txarray = phased.ULA('NumElements',4,'ElementSpacing',lambda/2);
txmopos = getElementPosition(txarray)/lambda;

rxarray = phased.ULA('NumElements',2,'ElementSpacing',lambda/2);
rxmopos = getElementPosition(rxarray)/lambda;

misochan = scatteringchanmtx(txsipos,rxmopos,txang,rxang,g);

%%
% In the MISO system, because the received signals across receive array
% elements are coherent, it is possible to steer the receive array toward
% the transmitter to improve the SNR. Note that this assumes that the
% signal incoming direction is known to the receiver. In reality, the angle
% is often obtained using direction of arrival estimation algorithms.

txarraystv = phased.SteeringVector('SensorArray',txarray,...
    'PropagationSpeed',c);
wr = conj(txarraystv(fc,rxang));
ber_miso = helperMIMOBER(misochan,x,ebn0_param,1,wr)/Nsamp;
%helperBERPlot(ebn0_param,[ber_siso(:) ber_simo(:) ber_miso(:)]); 
legend('SISO','SIMO','MISO')

%% 
% *MIMO LOS Channel*
% 
% Because a SIMO system provides an array gain from the received array and
% a MISO system provides an array gain from the transmit array, a MIMO
% system with an LOS propagation can benefit from both the transmit and
% receive array gain.
%
% Assume a MIMO system with a 4-element transmit array and a 4-element
% receive array.

mimochan = scatteringchanmtx(txmipos,rxmopos,txang,rxang,g);

%%
% To achieve the best SNR, the transmit array and the receive array need to
% be steered toward each other. With this configuration, the BER curve can
% be computed as

wt = txarraystv(fc,txang)';
wr = conj(rxarraystv(fc,rxang));
ber_mimo = helperMIMOBER(mimochan,x,ebn0_param,wt,wr)/Nsamp;
helperBERPlot(ebn0_param,[ber_siso(:) ber_simo(:) ber_miso(:) ber_mimo(:)]); 
title(" BER vs Eb/No for FR1 = 6GHz")
legend('SISO','SIMO','MISO','MIMO ')
%%
%% Improve SNR by Diversity Gain for Multipath Channel
% All the channels in the previous sections are line-of-sight channels.
% Although such channels are found in some wireless communication systems,
% in general wireless communications occurs in multipath fading
% environments. The rest of this example explores how using arrays can help
% in a multipath environment.

%%
% MULTIPATH CHANNEL 
%%
% *SISO Multipath Channel*
% 
% Assume there are 10 randomly placed scatterers in the channel, then there
% will be 10 paths from the transmitter to the receiver, as illustrated in
% the following figure.

Nscat = 10;

[~,~,~,scatpos] = ...
    helperComputeRandomScatterer(txcenter,rxcenter,Nscat);
helperPlotSpatialMIMOScene(txsipos,rxsopos,...
    txcenter,rxcenter,scatpos);

%%
% For simplicity, assume that signals traveling along all paths arrive
% within the same symbol period so the channel is frequency flat.
%
% To simulate the BER curve for a fading channel, the channel needs to
% change over time. Assume we have 1000 frames and each frame has 10000
% bits. The baseline SISO multipath channel BER curve is constructed as

Nframe = 1e3;
Nbitperframe = 1e4;
Nsamp = Nframe*Nbitperframe;

x = randi([0 1],Nbitperframe,1);

nerr = zeros(1,Nsnr);

for m = 1:Nframe
    sisompchan = scatteringchanmtx(txsipos,rxsopos,Nscat);
    wr = sisompchan'/norm(sisompchan);
    nerr = nerr+helperMIMOBER(sisompchan,x,ebn0_param,1,wr);
end
ber_sisomp = nerr/Nsamp;
helperBERPlot(ebn0_param,[ber_siso(:) ber_sisomp(:)]);
legend('SISO LOS','SISO Multipath');

%%
% Compared to the BER curve derived from an LOS channel, the BER falls off
% much slower with the increase of energy per bit to noise power spectral
% density ratio (Eb/N0) due to the fading caused by the multipath
% propagation.

%% 
% *SIMO Multipath Channel*
%
% As more receive antennas are used in the receive array, more copies of
% the received signals are available at the receiver. Again, assume a
% 4-element ULA at the receiver.

%%
% The optimal combining weights can be derived by matching the channel
% response. Such a combining scheme is often termed as maximum ratio
% combining (MRC). Although in theory such scheme requires the knowledge of
% the channel, in practice the channel response can often be estimated at
% the receive array.

nerr = zeros(1,Nsnr);

for m = 1:Nframe
    simompchan = scatteringchanmtx(txsipos,rxmopos,Nscat);
    wr = simompchan'/norm(simompchan);
    nerr = nerr+helperMIMOBER(simompchan,x,ebn0_param,1,wr);
end
ber_simomp = nerr/Nsamp;
helperBERPlot(ebn0_param,[ber_sisomp(:) ber_simomp(:)]);
legend('SISO Multipath','SIMO Multipath');

%%
% Note that the received signal is no longer weighted by a steering vector
% toward a specific direction. Instead, the receiving array weights in this
% case are given by the complex conjugate of the channel response.
% Otherwise it is possible that multipath could make the received signal
% out of phase with the transmitted signal. This assumes that the channel
% response is known to the receiver. If the channel response is unknown,
% pilot signals can be used to estimate the channel response.
%
% It can be seen from the BER curve that not only the SIMO system provides
% some SNR gains compared to the SISO system, but the slope of the BER
% curve of the SIMO system is also steeper compared to the BER curve of the
% SISO system. The gain resulted from the slope change is often referred to
% as the diversity gain.

%% 
% *MISO Multipath Channel*
%
% Things get more interesting when there is multipath propagation in a MISO
% system. First, if the channel is known to the transmitter, then the
% strategy to improve the SNR is similar to maximum ratio combining. The
% signal radiated from each element of the transmit array should be
% weighted so that the propagated signal can be added coherently at the
% receiver.

nerr = zeros(1,Nsnr);

for m = 1:Nframe
    misompchan = scatteringchanmtx(txmipos,rxsopos,Nscat);
    wt = misompchan'/norm(misompchan);
    nerr = nerr+helperMIMOBER(misompchan,x,ebn0_param,wt,1);
end
ber_misomp = nerr/Nsamp;

helperBERPlot(ebn0_param,[ber_sisomp(:) ber_simomp(:) ber_misomp(:)]);
legend('SISO Multipath','SIMO Multipath','MISO Multipath');

%%
% Note the transmit diversity gain shown in the BER curve. Compared to the
% SIMO multipath channel case, the performance of a MISO multipath system 
% is not as good. This is because there is only one copy of the received
% signal yet the transmit power gets spread among multiple paths. It is
% certainly possible to amplify the signal at the transmit side to achieve
% an equivalent gain, but that introduces additional cost.
%
% If the channel is not known to the transmitter, there are still ways to
% explore the diversity via space time coding. For example, Alamouti code
% is a well known coding scheme that can be used to achieve diversity gain
% when the channel is not known. Interested readers are encouraged to
% explore the Introduction to MIMO Systems example in Communications 
% Toolbox(TM).

%% 
% *MIMO Multipath Channel*
%
% The rest of this example focuses on a multipath MIMO channel. In
% particular, this section illustrates the case where the number of
% scatterers in the environment is larger than the number of elements in
% the transmit and receive arrays. Such an environment is often termed as a
% rich scattering environment.
%
% Before diving into the specific performance measures, it is helpful to
% get a quick illustration of what the channel looks like. The following
% helper function creates a 4x4 MIMO channel where both transmitter and
% receiver are 4-element ULAs.

[txang,rxang,scatg,scatpos] = ...
    helperComputeRandomScatterer(txcenter,rxcenter,Nscat);
mimompchan = scatteringchanmtx(txmipos,rxmopos,txang,rxang,scatg);

%%
% There are multiple paths available between the transmit array and the
% receive array because of the existence of the scatterers. Each path
% consists of a single bounce off the corresponding scatterer.

helperPlotSpatialMIMOScene(txmipos,rxmopos,txcenter,rxcenter,scatpos);

%%
% There are two ways to take advantage of a MIMO channel. The first way is
% to explore the diversity gain offered by a MIMO channel. Assuming the
% channel is known, the following figure shows the diversity gain with
% the BER curve.

nerr = zeros(1,Nsnr);

for m = 1:Nframe
    mimompchan = scatteringchanmtx(txmipos,rxmopos,Nscat);
    [u,s,v] = svd(mimompchan);
    wt = u(:,1)';
    wr = v(:,1);
    nerr = nerr+helperMIMOBER(mimompchan,x,ebn0_param,wt,wr);
end
ber_mimomp = nerr/Nsamp;

helperBERPlot(ebn0_param,[ber_sisomp(:) ber_simomp(:) ber_misomp(:) ber_mimomp(:)]);
legend('SISO Multipath','SIMO Multipath','MISO Multipath','MIMO Multipath');
saveas(gcf,'ber_multipath_all.png')


